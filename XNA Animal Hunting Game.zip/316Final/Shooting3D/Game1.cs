﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Drawing;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Media;

// CSC 316 Final Project
// Clifton Lindsey
// Corbin Kiefner
// Amber Lyons

namespace Shooting3D
{
    public class Game1 : Game
    {
        // Graphics
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        // Animals
        List<Model> models = new List<Model>();
        Model enemy;
        Model enemyA;
        Model enemyB;
        Model enemyC;
        Model enemyD;
        Model enemyE;
        Model enemyF;

        // Backdrops
        List<Texture2D> backGrounds = new List<Texture2D>();
        Texture2D groundA;
        Texture2D groundB;
        Texture2D groundC;
        int n = 0;

        // UI
        Texture2D crosshairSprite;
        SpriteFont gameFont;
        Vector2 crosshairPos;
        float crosshairRadius;

        // Music
        Song menuMusic;
        Song playMusic;

        // World matrices
        Matrix proj;
        Matrix view;
        Matrix world;
        Matrix worldGround;
        Matrix reticlePos;
        Viewport view2D;

        // Camera and animal positions
        Vector3 camPos;
        Vector3 enemyPos;
        Vector2 enemyPos2d;
        float enemyRotY;
        float enemyRotX;
        float delta;

        // Mouse control
        MouseState mState;
        Vector2 mPos;
        bool mReleasedLeft;
        float mouseTargetDist;
        int targetRadius;

        // Score tracking
        int score;
        float freezeTime;
        bool pause;
        static Random rand;
        int ammo;
        int priorScore;
        int highScore;

        // Menu control
        bool menuScreen = true;
        bool loadGame = false;
        bool endGame = false;

        // Miscelanious
        Vector2 centerAligned;
        Microsoft.Xna.Framework.Rectangle ButtonRect;
        Microsoft.Xna.Framework.Rectangle backGroundPlane;
        Texture2D Button_Texture;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = false;
        }

        protected override void Initialize()
        {
            // Set fullscreen
            _graphics.IsFullScreen = true;
            _graphics.PreferredBackBufferWidth = 1920;
            _graphics.PreferredBackBufferHeight = 1080;
            _graphics.ApplyChanges();

            // set camera and animal position/speed
            camPos = new Vector3(0, 3, 10);
            enemyPos = new Vector3(-10, 0, -10);
            enemyRotX = 0f;
            enemyRotY = 90f;
            delta = 0.1f;

            // Mouse controls
            crosshairPos = new Vector2(10, 10);
            crosshairRadius = 20f;
            mPos = new Vector2(0, 0);
            mouseTargetDist = 10000f;
            mReleasedLeft = true;
            targetRadius = 100;

            // Load music
            menuMusic = Content.Load<Song>("nightshade");
            playMusic = Content.Load<Song>("mountain");

            // Play Music
            MediaPlayer.Play(menuMusic);

            // Score tracking
            score = 0;
            freezeTime = 0.75f;
            pause = false;
            rand = new Random();
            ammo = 16;

            // Start Button
            centerAligned = new Vector2((_graphics.PreferredBackBufferWidth / 2) - 57, (_graphics.PreferredBackBufferWidth / 2) - 18);
            ButtonRect = new Microsoft.Xna.Framework.Rectangle((_graphics.PreferredBackBufferWidth / 2) - 60, (_graphics.PreferredBackBufferWidth / 2) - 30, 120, 60);

            // World Matrices
            backGroundPlane = new Microsoft.Xna.Framework.Rectangle(0, 0, 1920, 1080);
            view2D = new Viewport(0, 0, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);
            proj = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(60), 1, 0.001f, 1000f);
            view = Matrix.CreateLookAt(camPos, Vector3.Zero, Vector3.Up);  
            world = Matrix.CreateScale(0.005f) * Matrix.CreateRotationY(MathHelper.ToRadians(enemyRotY)) * Matrix.CreateTranslation(enemyPos);
            reticlePos = Matrix.CreateScale(0.005f) * Matrix.CreateRotationY(MathHelper.ToRadians(mPos.Y)) * Matrix.CreateTranslation(mPos.X, mPos.Y, 0);
            worldGround = Matrix.CreateScale(10, 0.001f, 10);
            enemyPos2d = new Vector2(view2D.Project(enemyPos, proj, view, world).X, view2D.Project(enemyPos, proj, view, world).Y);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            // Initialize spritebatch
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // Load animals
            enemy = Content.Load<Model>("Animal_Rigged_Zebu_01");
            enemyA = Content.Load<Model>("Animal_Rigged_Zebu_01");
            enemyB = Content.Load<Model>("butterfly");
            enemyC = Content.Load<Model>("cat");
            enemyD = Content.Load<Model>("chicken");
            enemyE = Content.Load<Model>("dog");
            enemyF = Content.Load<Model>("eagle");
            
            // Add animals to list
            models.Add(enemyA);
            models.Add(enemyB);
            models.Add(enemyC);
            models.Add(enemyD);
            models.Add(enemyE);
            models.Add(enemyF);

            // Load backgrounds
            groundA = Content.Load<Texture2D>("Forest");
            groundB = Content.Load<Texture2D>("Desert");
            groundC = Content.Load<Texture2D>("Snow");

            // Add backgrounds to list
            backGrounds.Add(groundA);
            backGrounds.Add(groundB);
            backGrounds.Add(groundC);

            // Load UI
            crosshairSprite = Content.Load<Texture2D>("crosshair_blue_small");
            gameFont = Content.Load<SpriteFont>("gamefont");
            Button_Texture = Content.Load<Texture2D>("wood");
        }

        protected override void Update(GameTime gameTime)
        {
            // Update mouse state and position
            mState = Mouse.GetState();
            mPos.X = mState.X;
            mPos.Y = mState.Y;

            // Update crosshair position
            crosshairPos.X = mPos.X - crosshairRadius;
            crosshairPos.Y = mPos.Y - crosshairRadius;

            // Escape to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            {
                System.Diagnostics.Trace.WriteLine("Exiting!");
                Exit();
            }

            // If in main menu and start button is clicked, start the game
            if (!loadGame && (Keyboard.GetState().IsKeyDown(Keys.Enter) || (mState.LeftButton == ButtonState.Pressed && ButtonRect.Contains(mState.X, mState.Y))))
            {
                // Switch to game menu
                System.Diagnostics.Trace.WriteLine("Button Clicked!");
                loadGame = true;
                menuScreen = false;
                endGame = false;
                ammo = 15;

                // Change music
                MediaPlayer.Stop();
                MediaPlayer.Play(playMusic);

                // Select background from list
                if (n < 2)
                {
                    n++;
                }
                else
                {
                    n = 0;
                }
            }

            // If game is running
            if (loadGame)
            {
                // Escape to close game
                if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                    Exit();

                // When enemy dies, pause for a moment and send another
                if (pause == true)
                {
                    if (freezeTime > 0)
                    {
                        freezeTime -= (float)1 / 60;
                    }
                    else
                    {
                        // Select new enemy model
                        Random rnJesus = new Random();
                        int num = rnJesus.Next(0, 6);
                        enemy = models[num];

                        // create new enemy
                        enemyRotX = 0;
                        enemyPos.X = -20;
                        enemyPos.Z = rand.Next(-20, 5);
                        pause = false;
                    }
                }
                else
                {
                    // Update enemy position
                    enemyPos.X += delta;

                    // Change enemy 2D pos
                    enemyPos2d = new Vector2(view2D.Project(enemyPos, proj, view, world).X,
                                             view2D.Project(enemyPos, proj, view, world).Y);

                    // If animal goes off screen cull and send another
                    if (enemyPos2d.X > _graphics.PreferredBackBufferWidth + 150)
                    {
                        freezeTime = 0.75f;
                        pause = true;
                    }

                    // Update score according to animals shot
                    if (mState.LeftButton == ButtonState.Pressed && mReleasedLeft == true)
                    {
                        // Firing always consumes ammo
                        ammo--;
                        mouseTargetDist = Vector2.Distance(mPos, enemyPos2d);

                        // If player hits target
                        if (mouseTargetDist < targetRadius)
                        {
                            // Increase score and kill target
                            score++;
                            enemyRotX = -90;
                            freezeTime = 0.75f;
                            pause = true;
                        }
                        mReleasedLeft = false;
                    }

                    // Update mouse button status
                    if (mState.LeftButton == ButtonState.Released)
                    {
                        mReleasedLeft = true;
                    }

                    // If no remaining ammo
                    if (ammo <= 0)
                    {
                        // Update highscore
                        if (highScore <= score)
                        {
                            highScore = score;
                        }
                        priorScore = score;
                        score = 0;

                        // Switch menus
                        menuScreen = false;
                        loadGame = false;
                        endGame = true;
                    }
                }

                // Update world matrix
                world = Matrix.CreateScale(0.005f) *
                        Matrix.CreateRotationY(MathHelper.ToRadians(enemyRotY)) *
                        Matrix.CreateRotationX(MathHelper.ToRadians(enemyRotX)) *
                        Matrix.CreateTranslation(enemyPos);

                base.Update(gameTime);
            }
        }

        protected override void Draw(GameTime gameTime)
        {
            // Set world color
            GraphicsDevice.Clear(Microsoft.Xna.Framework.Color.CornflowerBlue);

            // Draw Main Menu
            if (menuScreen)
            {
                _spriteBatch.Begin();

                _spriteBatch.DrawString(gameFont, "Welcome to", new Vector2(900, 400), Microsoft.Xna.Framework.Color.Black);
                _spriteBatch.DrawString(gameFont, "Animal Hunter!", new Vector2(890, 425), Microsoft.Xna.Framework.Color.White);

                _spriteBatch.DrawString(gameFont, "Shoot the animals to gain score," +
                    " but watch your ammo count!", new Vector2(700, 460), Microsoft.Xna.Framework.Color.Black);
                _spriteBatch.DrawString(gameFont, "Once you run out, you will move on to the next level.", new Vector2(740, 485), Microsoft.Xna.Framework.Color.Black);

                _spriteBatch.DrawString(gameFont, "Click Start to begin.", new Vector2(870, 540), Microsoft.Xna.Framework.Color.White);

                _spriteBatch.Draw(Button_Texture, ButtonRect, Microsoft.Xna.Framework.Color.White);
                _spriteBatch.DrawString(gameFont, "START!", centerAligned, Microsoft.Xna.Framework.Color.Black);
                _spriteBatch.Draw(crosshairSprite, crosshairPos, Microsoft.Xna.Framework.Color.Black);

                _spriteBatch.End();
            }

            // Draw gameplay
            if (loadGame)
            {
                _spriteBatch.Begin(SpriteSortMode.Immediate);

                _spriteBatch.Draw(backGrounds[n], new Vector2(0, 0), backGroundPlane, Microsoft.Xna.Framework.Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);

                _spriteBatch.DrawString(gameFont, "Ammunition: " + ammo.ToString(),
                                        new Vector2(100, 10), Microsoft.Xna.Framework.Color.Black);
                _spriteBatch.DrawString(gameFont, "Score: " + score.ToString(),
                                        new Vector2(100, 50), Microsoft.Xna.Framework.Color.Black);

                _spriteBatch.Draw(crosshairSprite, crosshairPos, Microsoft.Xna.Framework.Color.Black);

                enemy.Draw(world, view, proj);  

                _spriteBatch.End();
            }

            // Draw End Menu
            if (endGame)
            {
                GraphicsDevice.Clear(Microsoft.Xna.Framework.Color.Green);

                _spriteBatch.Begin();
                
                _spriteBatch.DrawString(gameFont, "You Ran Out Of Ammo!",
                    new Vector2
                    {
                        X = _graphics.PreferredBackBufferWidth / 2 - gameFont.MeasureString("Time's Up!").X / 2,
                        Y = _graphics.PreferredBackBufferWidth / 4 - gameFont.MeasureString("Time's Up!").Y
                    },
                    Microsoft.Xna.Framework.Color.White);


                _spriteBatch.DrawString(gameFont, "Final Score: " + priorScore.ToString(),
                    new Vector2
                    {
                        X = _graphics.PreferredBackBufferWidth / 2 - gameFont.MeasureString("Final Score:  ").X / 2,
                        Y = _graphics.PreferredBackBufferWidth / 3 - gameFont.MeasureString("Final Score:  ").Y
                    },
                    Microsoft.Xna.Framework.Color.White);

                _spriteBatch.DrawString(gameFont, "High Score: " + highScore.ToString(),
                    new Vector2
                    {
                        X = _graphics.PreferredBackBufferWidth / 2 - gameFont.MeasureString("High Score:  ").X / 2,
                        Y = _graphics.PreferredBackBufferWidth / 5 - gameFont.MeasureString("High Score:  ").Y
                    },
                    Microsoft.Xna.Framework.Color.White);

                _spriteBatch.Draw(Button_Texture, ButtonRect, Microsoft.Xna.Framework.Color.White);
                _spriteBatch.DrawString(gameFont, "Play Again!", centerAligned, Microsoft.Xna.Framework.Color.Black);
                _spriteBatch.Draw(crosshairSprite, crosshairPos, Microsoft.Xna.Framework.Color.Black);
                _spriteBatch.End();
            }

            base.Draw(gameTime);
        }
    }
}
